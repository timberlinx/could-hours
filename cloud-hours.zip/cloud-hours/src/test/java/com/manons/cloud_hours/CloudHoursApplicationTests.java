package com.manons.cloud_hours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudHoursApplicationTests {

	@Test
	void contextLoads() {
	}

}
